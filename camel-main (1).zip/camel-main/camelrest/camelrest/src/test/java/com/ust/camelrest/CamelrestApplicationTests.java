package com.ust.camelrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelrestApplicationTests {

	@Test
	void contextLoads() {
	}

}

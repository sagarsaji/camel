package com.ust.camelrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelrestApplication.class, args);
	}

}

package com.ust.camelrestmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelrestmongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelrestmongodbApplication.class, args);
	}

}

package com.ust.camelrestmongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelrestmongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}

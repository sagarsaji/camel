package com.ust.camelrestapimongo.service;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

@Component
public class EmployeeService {
	
	public void employeeProcess(Exchange exchange) {
		
		int id = exchange.getIn().getHeader("id",Integer.class);
		exchange.getIn().setBody(id);
		
	}

}

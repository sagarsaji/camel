package com.ust.camelrestapimongo.route;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mongodb.MongoDbConstants;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mongodb.BasicDBObject;
import com.mongodb.client.model.Filters;
import com.ust.camelrestapimongo.entity.Employee;
import com.ust.camelrestapimongo.service.EmployeeService;

@Component
public class CamelRoute extends RouteBuilder {
	
	@Autowired
	private EmployeeService employeeService;

	@Override
	public void configure() throws Exception {

		rest()
			.post("/add").type(Employee.class).to("direct:addemployees")
			.get("/get").to("direct:getemployees")
			.get("/get/{id}").to("direct:getemployeebyid")
			.get("/get/details/{name}").to("direct:getbyname");
		
		

		from("direct:addemployees").unmarshal().json(JsonLibrary.Jackson, Employee.class)
				.to("mongodb:mydb?database=employeedb&collection=employee&operation=insert")
				.marshal().json();

		
		
		from("direct:getemployees")
		.to("mongodb:mydb?database=employeedb&collection=employee&operation=findAll")
		.marshal().json();

		
		
		from("direct:getemployeebyid")
		.bean("employeeService","employeeProcess")
		.to("mongodb:mydb?database=employeedb&collection=employee&operation=findById")
		.marshal().json()
		.log("${body}");
		
		
		
		from("direct:getbyname")
	    .process(exchange -> {
	        String name = exchange.getIn().getHeader("name", String.class);
	        BasicDBObject query = new BasicDBObject("name", name);
	        System.out.println(query);
	        exchange.getMessage().setBody(query);
	    })
	    .to("mongodb:mydb?database=employeedb&collection=employee&operation=findOneByQuery")
	    .marshal().json()
	    .log("${body}");



		
		




	}

}

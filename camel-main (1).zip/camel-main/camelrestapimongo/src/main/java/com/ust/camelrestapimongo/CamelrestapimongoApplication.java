package com.ust.camelrestapimongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelrestapimongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelrestapimongoApplication.class, args);
	}

}

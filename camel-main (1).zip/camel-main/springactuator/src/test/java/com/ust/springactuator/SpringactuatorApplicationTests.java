package com.ust.springactuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringactuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}

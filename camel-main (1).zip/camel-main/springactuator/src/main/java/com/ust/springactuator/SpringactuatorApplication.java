package com.ust.springactuator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringactuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringactuatorApplication.class, args);
	}

}

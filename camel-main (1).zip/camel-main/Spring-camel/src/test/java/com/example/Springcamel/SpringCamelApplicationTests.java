package com.example.Springcamel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCamelApplicationTests {

	@Test
	void contextLoads() {
	}

}

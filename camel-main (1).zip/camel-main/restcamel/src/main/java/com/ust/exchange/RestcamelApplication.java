package com.ust.exchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestcamelApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestcamelApplication.class, args);
	}

}

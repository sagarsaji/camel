package com.ust.header;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeaderApplication.class, args);
	}

}
